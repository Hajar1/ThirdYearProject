"# project-team-smalltalkers" 

Git Repo: https://github.com/SYSC3110/project-team-smalltalkers

Group Members:
Mohammed Omar Khan - 100983417
Omar Ibrahim - 100943448
Adnan Hajar - 100983224
Ali Faizan - 100935765
