import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

/**
 * 
 */


public class StrategyTest {
	
	Attribute attribute = null;
	Node A = null;
	Node B = null;
	Strategy strategy = null;
	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		A = new Node('A', 10, 10);
		B = new Node('B', 20, 20);
		attribute = new Attribute("Hi", A, B, 2);
		strategy = new RandomRoutingAlgorithm(attribute);
	}

	/**
	 * Test method for {@link Strategy#algorithmInterface()}.
	 */
	
	/**
	@Test
	public final void testAlgorithmInterface() {
		fail("Not yet implemented"); // TODO
	}
	*/

	/**
	 * Test method for {@link Strategy#setAttribute(Attribute)}.
	 */
	@Test
	public final void testSetAttribute() {
		Attribute test = new Attribute("Test",new Node('C', 10, 10), new Node('D', 20, 20), 4);
		strategy.setAttribute(test);
		assertEquals(test, strategy.getAttribute());
	}

	/**
	 * Test method for {@link Strategy#getAttribute()}.
	 */
	@Test
	public final void testGetAttribute() {
		assertEquals(attribute, strategy.getAttribute());
	}

}
