import java.util.LinkedList;
import java.util.Queue;

/**
 * Class for breadth first search.  
 */
public class BreadthFirstSearchRoutingAlgorithm extends Strategy {
	Queue<Node> queue;
	int current =0;
	
	
	/**
	 * Constructor for Breadth First Search. 
	 * Not Yet Implemented. 
	 */
	  public BreadthFirstSearchRoutingAlgorithm(Attribute attribute){
		  this.attribute = attribute;		 
		  queue = new LinkedList();
			queue.add(attribute.getCurrentNode());
	  }
	/**
	 * Algorithm for breadth first search.  
	 * Not Yet Implemented. 
	 */
	  public Node getNextNode(){
		  Node temp= queue.remove();
		//  System.out.println("Getting next Node");
		  addNeighborsToList(temp);
		  //printQueue();
		  return temp;
	  }
	  
	  public void addNeighborsToList(Node node){
		  for(Node e:node.getNeighbours()){
			  queue.add(e);			  
		  }
		  
		  
	  }
	  
	  public void attributeLocationChanger(Node newCurrentnode){
		  	attribute.setOldNode(attribute.getCurrentNode());
			attribute.setCurrentNode(newCurrentnode);
			attribute.incrementHops();
			attribute.incrementPackets();
		  
	  }
	  
	  public Attribute algorithmInterface(){
		 
			
			if(!queue.isEmpty()){
				Node node = getNextNode();
				attributeLocationChanger(node);
				//System.out.println("Current node" + node);
		//attribute.getCurrentNode().addAttribute(attribute);
					if(node == attribute.getDestinationNode()){
						//found the attribute
						//System.out.println("I reached my destination!");
						return attribute;
					}
					System.out.println(getAttribute().toString());
					attribute.getCurrentNode().setMessage(getAttribute().getMessage());	
			}
			else{System.out.println("something went wrong");
			}
			return attribute;
			
	  }
}

