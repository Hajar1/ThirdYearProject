import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.math.BigDecimal;
import java.math.MathContext;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.text.DefaultCaret;

import com.mxgraph.swing.mxGraphComponent;
import com.mxgraph.view.mxGraph;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;

import javax.swing.border.BevelBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EtchedBorder;
import java.awt.Color;
import java.awt.SystemColor;

//import com.mxgraph.swing.mxGraphComponent;
//import com.mxgraph.view.mxGraph;

public class NetworkGUI extends JFrame implements ActionListener {

	private static Model model; // Top level view of our graph/network
	private JMenuItem save;
	private JMenu networkMenu;
	private JList<Node> nodeJList;
	private JTextField message, rate, avgHopField, numPacketField, sourceNodeField, destinationNodeField;
	private JMenuBar networkMenuBar;
	private JLabel textNetworkLabel, messageLabel, rateLabel, inputScannerLabel, totalPacketsLabel, destinationNodeLabel;
	private JButton startSimButton, stepButton;
	private JPanel printingPanel, visualPanel;
	private JRadioButton rrrRadioButton, bfsRadioButton, floodingRadioButton, aStarRadioButton;
	private ButtonGroup radioButtonGroup; // Makes sure only one button is selected at a time
	private static JTextArea ConsolTextArea;
	private static String input;
	private static boolean buttonRead;
	private int nodeCount = 0, shiftRight = 0, shiftDown = 0;
	// protected static mxGraph graph = new mxGraph();
	// private mxGraphComponent graphComponent;
	private ArrayList<Node> nodeList;
	// Global variables to read data into
	private String messageVariable;
	private char currentNode, destinationNode;
	private int rateVariable, selectedAlgorithmVariable, numPacketsVariable = 0, avgNumOfHopsVariable = 0;
	private Attribute attribute = null;

	
	protected static mxGraph graph = new mxGraph();
	protected static HashMap m = new HashMap();
	private mxGraphComponent graphComponent;
	private JTextField nodeNameField;
	private JButton addNodeButton,quickPopulateBtn;
	private JButton deleteElementButton;
	private JButton connectNodesButton;
	private Object graphElement;
	private JTextField textField;
	private JLabel lblGraphRepresentation;
	private final Action action = new SwingAction();

	
	
	public NetworkGUI() {
		setTitle("Network Routing Simulator - V2.0");
		getContentPane().setForeground(SystemColor.info);
		getContentPane().setBackground(SystemColor.activeCaption);

		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(988, 594);

		networkMenuBar = new JMenuBar();
		this.setJMenuBar(networkMenuBar);
		networkMenu = new JMenu("Network");

		networkMenuBar.add(networkMenu);

		save = new JMenuItem("Save this Network");
		save.setEnabled(false);
		save.addActionListener(this);
		networkMenu.add(save);
		
		JMenu mnCopyrights = new JMenu("CopyRights");
		networkMenuBar.add(mnCopyrights);
		
		JMenuItem mntmAdnanHajar = new JMenuItem("Adnan Hajar - 100983224");
		mntmAdnanHajar.setEnabled(false);
		mnCopyrights.add(mntmAdnanHajar);
		
		JMenuItem mntmAliFaizan = new JMenuItem("Ali Faizan - 100935765");
		mntmAliFaizan.setEnabled(false);
		mnCopyrights.add(mntmAliFaizan);
		
		JMenuItem mntmOmarIbrahim = new JMenuItem("Omar Ibrahim - 100943448");
		mntmOmarIbrahim.setEnabled(false);
		mnCopyrights.add(mntmOmarIbrahim);
		
		JMenuItem mntmOmarRasheed = new JMenuItem("Omar Rasheed -100983417");
		mntmOmarRasheed.setIcon(new ImageIcon("C:\\Users\\adnanhajar\\Desktop\\project-team-smalltalkers-milestone2-prealpha\\project-team-smalltalkers-milestone2-prealpha\\copyright.png"));
		mntmOmarRasheed.setEnabled(false);
		mnCopyrights.add(mntmOmarRasheed);
		getContentPane().setLayout(null);

		startSimButton = new JButton("Start Simulation");
		startSimButton.setBounds(485, 56, 181, 23);
		getContentPane().add(startSimButton);
		startSimButton.addActionListener(this);
		startSimButton.setEnabled(false);

		stepButton = new JButton("Step");
		stepButton.setBounds(676, 56, 95, 23);
		getContentPane().add(stepButton);
		stepButton.addActionListener(this);
		stepButton.setEnabled(false);

		printingPanel = new JPanel();
		printingPanel.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		printingPanel.setBounds(485, 216, 450, 308);
		getContentPane().add(printingPanel);
		printingPanel.setLayout(null);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 11, 434, 286);
		printingPanel.add(scrollPane);

		ConsolTextArea = new JTextArea();
		scrollPane.setViewportView(ConsolTextArea);
		
				textNetworkLabel = new JLabel("Network in Text");
				textNetworkLabel.setHorizontalAlignment(SwingConstants.CENTER);
				scrollPane.setColumnHeaderView(textNetworkLabel);
		PrintStream out = new PrintStream( new TextAreaOutputStream( ConsolTextArea ) );

		   DefaultCaret caret = (DefaultCaret)ConsolTextArea.getCaret();
		    caret.setUpdatePolicy(DefaultCaret.OUT_BOTTOM);
		        // re-assigns standard output stream and error output stream
		      System.setOut(out);
		       System.setErr(out);
				
				
				
		visualPanel = new JPanel();
		visualPanel.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		visualPanel.setBounds(20, 54, 450, 402);
		initGUI(visualPanel);
		// graphComponent = new mxGraphComponent(graph);
		// visualPanel.add(graphComponent, BorderLayout.EAST);
		// this.add(visualPanel);

		getContentPane().add(visualPanel);
		
		message = new JTextField("Hello World!");
		message.setBounds(570, 90, 75, 20);
		getContentPane().add(message);
		message.setColumns(10);
		message.setEnabled(false);

		rate = new JTextField("3");
		rate.setColumns(10);
		rate.setBounds(790, 90, 86, 20);
		getContentPane().add(rate);
		rate.addActionListener(this);
		rate.setEnabled(false);
		
		sourceNodeField = new JTextField("a");
		sourceNodeField.setBounds(570, 116, 75, 20);
		getContentPane().add(sourceNodeField);
		sourceNodeField.setColumns(10);
		sourceNodeField.setEnabled(false);
		
		destinationNodeField = new JTextField("b");
		destinationNodeField.setBounds(790, 116, 86, 20);
		getContentPane().add(destinationNodeField);
		destinationNodeField.setColumns(10);
		destinationNodeField.setEnabled(false);
		
		avgHopField = new JTextField();
		avgHopField.setBounds(139, 501, 94, 23);
		avgHopField.setEditable(false);
		avgHopField.setColumns(10);
		avgHopField.addActionListener(this);
		getContentPane().add(avgHopField);
		
		numPacketField = new JTextField();
		numPacketField.setColumns(10);
		numPacketField.setBounds(369, 501, 106, 23);
		numPacketField.setEditable(false);
		getContentPane().add(numPacketField);
		
		rrrRadioButton = new JRadioButton("RandomRoutingAlgorithm", true);
		rrrRadioButton.setBounds(487, 157, 173, 23);
		rrrRadioButton.setMnemonic(1);
		getContentPane().add(rrrRadioButton);

		bfsRadioButton = new JRadioButton("BreathFirstSearchAlgorithm");
		bfsRadioButton.setBounds(674, 157, 173, 23);
		bfsRadioButton.setMnemonic(2);
		getContentPane().add(bfsRadioButton);

		floodingRadioButton = new JRadioButton("FloodingAlgorithm");
		floodingRadioButton.setBounds(487, 183, 173, 23);
		floodingRadioButton.setMnemonic(3);
		getContentPane().add(floodingRadioButton);

		aStarRadioButton = new JRadioButton("AstarAlgorithm");
		aStarRadioButton.setBounds(674, 183, 173, 23);
		aStarRadioButton.setMnemonic(4);
		getContentPane().add(aStarRadioButton);

		// Makes sure only one button is selected at a time
		radioButtonGroup = new ButtonGroup();
		radioButtonGroup.add(aStarRadioButton);
		radioButtonGroup.add(floodingRadioButton);
		radioButtonGroup.add(rrrRadioButton);
		radioButtonGroup.add(bfsRadioButton);
		radioButtonsOff();

		messageLabel = new JLabel("Message:");
		messageLabel.setBounds(485, 93, 75, 14);
		getContentPane().add(messageLabel);

		rateLabel = new JLabel("Rate:");
		rateLabel.setBounds(676, 93, 29, 14);
		getContentPane().add(rateLabel);

		destinationNodeLabel = new JLabel("Destination Node:");
		destinationNodeLabel.setBounds(676, 121, 116, 14);
		getContentPane().add(destinationNodeLabel);

		inputScannerLabel = new JLabel("Average # of Hops");
		inputScannerLabel.setBounds(20, 505, 114, 14);
		getContentPane().add(inputScannerLabel);

		totalPacketsLabel = new JLabel("Total # of Packets");
		totalPacketsLabel.setBounds(256, 505, 115, 14);
		getContentPane().add(totalPacketsLabel);
		
		quickPopulateBtn = new JButton("Quick Populate");
		quickPopulateBtn.setBounds(777, 56, 150, 23);
		getContentPane().add(quickPopulateBtn);
		quickPopulateBtn.addActionListener(this);
		
		addNodeButton = new JButton("Add Node");
		addNodeButton.setBounds(144, 467, 89, 23);
		getContentPane().add(addNodeButton);
		addNodeButton.addActionListener(this);
		
		deleteElementButton = new JButton("Delete Node");
		deleteElementButton.setBounds(256, 467, 120, 23);
		getContentPane().add(deleteElementButton);
		deleteElementButton.addActionListener(this);
		
		connectNodesButton = new JButton("Connect");
		connectNodesButton.setBounds(386, 467, 89, 23);
		getContentPane().add(connectNodesButton);
		connectNodesButton.addActionListener(this);
		
		nodeNameField = new JTextField();
		nodeNameField.setBounds(20, 468, 114, 20);
		getContentPane().add(nodeNameField);
		nodeNameField.setColumns(10);
		nodeNameField.addActionListener(this);
		
		JLabel lblStartNode = new JLabel("Start Node:");
		lblStartNode.setBounds(485, 121, 95, 15);
		getContentPane().add(lblStartNode);
		
		

		this.setVisible(true);
		printToGUI("Routing Simulator - Version 2.0\n");

		// Initializing Model
		model = new Model(); // Make the network and call the Model function to
		
								// make the graph
		nodeList = new ArrayList<Node>();

	} // End of Constructor

	public static void printToGUI(String s) {

		ConsolTextArea.append(s);
	}

	public static void main(String args[]) {

		NetworkGUI network = new NetworkGUI();
		// Want to populate the graph for quick testing purposes
		printToGUI("Type 'Y' to populate the network for quick testing purposes?: ");
		buttonRead = false;
		// printToGUI("\nYou typed: " + input);

		printToGUI("" + buttonRead);

		while (!buttonRead) {
		}
		printToGUI("" + buttonRead);
		switch (input) {
		case "Y":
			printToGUI("\nYou typed Y");
			buttonRead = false;
			break;

		}

	}

	@Override
	public void actionPerformed(ActionEvent event) {
		if (event.getSource() == addNodeButton) {
			Random index = new Random();
			String name = nodeNameField.getText();
			if(!name.isEmpty()){	
			int width = index.nextInt(visualPanel.getWidth()-100);
			int height =index.nextInt(visualPanel.getHeight()-100);
			graph.getModel().beginUpdate();
			Object parent = graph.getDefaultParent();
			Object v1 = graph.insertVertex(parent, null, name,width,height,50, 50,"shape=ellipse");
			
			getM().put(name, v1);
			model.getListOfNodes().add(new Node(name.charAt(0),width,height));
			
			graph.getModel().endUpdate();
			nodeNameField.setText("");
			}
		}

		else if (event.getSource() == deleteElementButton) {
			graph.getModel().remove(graphElement);
		}

		else if (event.getSource() == connectNodesButton) {
			Object parent = graph.getDefaultParent();
			String a,b;
			a = JOptionPane.showInputDialog("Enter first Node:");
			b = JOptionPane.showInputDialog("Enter second Node:");
			Object v1 = getM().get(a);
			Object v2 = getM().get(b);
			//String nome = JOptionPane.showInputDialog("Add Message to Arrow");
			graph.insertEdge(parent, null, "", v1, v2, "endArrow=none;");
			radioButtonsOn();
			Sim_On();
			model.connect(a.charAt(0),b.charAt(0));
			startSimButton.setEnabled(true);
			message.setEnabled(true);
			rate.setEnabled(true);
			sourceNodeField.setEnabled(true);
			destinationNodeField.setEnabled(true);
			radioButtonsOn();
			
			
			
			
		}
		else if (event.getSource() == startSimButton) {
			messageVariable = message.getText();
			currentNode = (char) sourceNodeField.getText().charAt(0);
			destinationNode = (char) destinationNodeField.getText().charAt(0);
			
			// Will be good once add node is working
			//attribute = model.createAttribute(messageVariable, currentNode,destinationNode);
			radioButtonsOff(); // Sets radio button to off
			//startSimButton.setEnabled(false);
			model.setRate(Integer.parseInt(rate.getText()));	// Sets the rate of the algorithm
			
			printToGUI("Rate = " + model.getRate());
			
			selectedAlgorithmVariable = radioButtonGroup.getSelection().getMnemonic();
			printToGUI("Button selected = " + selectedAlgorithmVariable);
			switch (selectedAlgorithmVariable) {
			case 1:
				Random index = new Random(model.getListOfNodes().size());
				printToGUI("\n\nIn Random Alogrithm");
				model.createAttribute(messageVariable, currentNode  ,destinationNode );
				printToGUI("Exiting Random Alogrithm");
				break;
			case 2:
				printToGUI("In BFS Alogrithm");
				printToGUI("Exiting BFS Alogrithm");
			case 3:
				printToGUI("In BFS Alogrithm");
				printToGUI("Exiting BFS Alogrithm");
				
			default:
				printToGUI("You did not select an algorithm");
				break;
				
				}

			this.stepButton.setEnabled(true);
			this.addNodeButton.setEnabled(false);
			this.deleteElementButton.setEnabled(false);
			this.connectNodesButton.setEnabled(false);
			message.setEnabled(false);
			startSimButton.setEnabled(false);
			
			rate.setEnabled(false);
			sourceNodeField.setEnabled(false);
			destinationNodeField.setEnabled(false);
			this.nodeNameField.setEnabled(false);
			this.quickPopulateBtn.setEnabled(false);
			
		}
		else if (event.getSource() == nodeNameField) {
			Random index = new Random();
			String name = nodeNameField.getText();
			if(!name.isEmpty()){
			int width = index.nextInt(visualPanel.getWidth()-100);
			int height =index.nextInt(visualPanel.getHeight()-100);
			graph.getModel().beginUpdate();
			Object parent = graph.getDefaultParent();
			Object v1 = graph.insertVertex(parent, null, name,width,height,50, 50,"shape=ellipse");
			
			getM().put(name, v1);
			model.getListOfNodes().add(new Node(name.charAt(0),width,height));
			
			graph.getModel().endUpdate();
			nodeNameField.setText("");
			}
		
			
		}
		else if (event.getSource() == stepButton) {
			model.stepSimulate();
			BigDecimal bd = new BigDecimal(model.getHopsAverage());
			bd = bd.round(new MathContext(6));
			double rounded = bd.doubleValue();
			avgHopField.setText("" + rounded);
			numPacketField.setText("" + model.getNumOfPackets());
			
			
			
			
		}
		else if (event.getSource() == quickPopulateBtn) {
			
			ActionEvent  e;
			 char x='a';
			 Object v1;
			 Object v2;
			 String a = "a";
			 String b = "b";
			 Object parent = graph.getDefaultParent();
			for ( int i =0; i<5; i++){
			
				nodeNameField.setText(""+ x++);
				e = new ActionEvent(addNodeButton,1001,"Add Node");
				addNodeButton.doClick();
			}
			
			
			v1 = getM().get(a);
			v2 = getM().get(b);
			//String nome = JOptionPane.showInputDialog("Add Message to Arrow");
			graph.insertEdge(parent, null, "", v1, v2, "endArrow=none;");
			model.connect(a.charAt(0),b.charAt(0));
			
			a = "e";
			b = "b";
			v1 = getM().get(a);
			v2 = getM().get(b);
			//String nome = JOptionPane.showInputDialog("Add Message to Arrow");
			graph.insertEdge(parent, null, "", v1, v2, "endArrow=none;");
			model.connect(a.charAt(0),b.charAt(0));
			
			
			a = "a";
			b = "e";
			v1 = getM().get(a);
			v2 = getM().get(b);
			//String nome = JOptionPane.showInputDialog("Add Message to Arrow");
			graph.insertEdge(parent, null, "", v1, v2, "endArrow=none;");
			model.connect(a.charAt(0),b.charAt(0));
			
			a = "d";
			b = "b";
			v1 = getM().get(a);
			v2 = getM().get(b);
			//String nome = JOptionPane.showInputDialog("Add Message to Arrow");
			graph.insertEdge(parent, null, "", v1, v2, "endArrow=none;");
			model.connect(a.charAt(0),b.charAt(0));
			
			a = "d";
			b = "c";
			v1 = getM().get(a);
			v2 = getM().get(b);
			//String nome = JOptionPane.showInputDialog("Add Message to Arrow");
			graph.insertEdge(parent, null, "", v1, v2, "endArrow=none;");
			model.connect(a.charAt(0),b.charAt(0));
			
			a = "a";
			b = "c";
			v1 = getM().get(a);
			v2 = getM().get(b);
			//String nome = JOptionPane.showInputDialog("Add Message to Arrow");
			graph.insertEdge(parent, null, "", v1, v2, "endArrow=none;");
			model.connect(a.charAt(0),b.charAt(0));
			
			a = "e";
			b = "b";
			v1 = getM().get(a);
			v2 = getM().get(b);
			//String nome = JOptionPane.showInputDialog("Add Message to Arrow");
			graph.insertEdge(parent, null, "", v1, v2, "endArrow=none;");
			model.connect(a.charAt(0),b.charAt(0));
			
			
			radioButtonsOn();
			Sim_On();
			startSimButton.setEnabled(true);
			message.setEnabled(true);
			rate.setEnabled(true);
			sourceNodeField.setEnabled(true);
			destinationNodeField.setEnabled(true);
			radioButtonsOn();
			this.addNodeButton.setEnabled(false);
			this.deleteElementButton.setEnabled(false);
			this.connectNodesButton.setEnabled(false);
			nodeNameField.setEnabled(false);
			
			
			
		}
		
		
		

	}
	
	
	private void initGUI(JPanel visualPanel2) {
		
		lblGraphRepresentation = new JLabel("Graph Representation");
		lblGraphRepresentation.setHorizontalAlignment(SwingConstants.CENTER);
		visualPanel2.add(lblGraphRepresentation);
		graphComponent = new mxGraphComponent(graph);
		graphComponent.setPreferredSize(visualPanel2.getSize());
		visualPanel2.add(graphComponent);
	

		graphComponent.getGraphControl().addMouseListener(new MouseAdapter() {
			public void mouseReleased(MouseEvent e) {
				graphElement = graphComponent.getCellAt(e.getX(), e.getY());
			}
		});
	}

	
	public static HashMap getM() {
		return m;
	}
	
	private void Sim_On(){
		startSimButton.setEnabled(true);
		
	}

	
	private void radioButtonsOn() {
		rrrRadioButton.setEnabled(true);
		bfsRadioButton.setEnabled(false);
		floodingRadioButton.setEnabled(false); // false since it wasnt implemented yet
		aStarRadioButton.setEnabled(false);
	}
	
	private void radioButtonsOff() {
		rrrRadioButton.setEnabled(false);
		bfsRadioButton.setEnabled(false);
		floodingRadioButton.setEnabled(false);
		aStarRadioButton.setEnabled(false);
	}
	private class SwingAction extends AbstractAction {
		public SwingAction() {
			putValue(NAME, "SwingAction");
			putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {
		}
	}
}
