import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;

/**
 * 
 */

public class NodeTest {
	
	private Node A = null;
	private Node D = null;

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		A = new Node('A', 2, 4);
		D = new Node('D', 3, 5);
		
		A.addNeighbour(D);
		
	}

	/**
	 * Test method for {@link Node#Node(char, int, int)}.
	 */
	@Test
	public final void testNode() {
		Node T = new Node('T', 5, 8);
		assertTrue(T.getName() == 'T');
		assertTrue(T.getx_Loc() == 5);
		assertTrue(T.gety_Loc() == 8);
		assertTrue(T.getNeighbours().size() == 0);
		assertTrue(T.getAttributes().size() == 0);
	}

	/**
	 * Test method for {@link Node#getName()}.
	 */
	@Test
	public final void testGetName() {
		assertEquals('A', A.getName());
	}

	/**
	 * Test method for {@link Node#getNeighbours()}.
	 */
	@Test
	public final void testGetNeighbours() {
		assertTrue(A.getNeighbours().size() == 1 && A.getNeighbours().contains(D));
	}

	/**
	 * Test method for {@link Node#addNeighbour(Node)}.
	 */
	@Test
	public final void testAddNeighbour() {
		Node B = new Node('B', 1, 2);
		A.addNeighbour(B);
		assertTrue(A.getNeighbours().size() == 2 && A.getNeighbours().contains(B) && A.getNeighbours().contains(D));
	}

	/**
	 * Test method for {@link Node#removeNeighbour(Node)}.
	 */
	@Test
	public final void testRemoveNeighbour() {
		Node B = new Node('B', 1, 2);
		Node C = new Node('C', 1, 5);
		
		A.addNeighbour(B);
		A.addNeighbour(C);
		
		A.removeNeighbour(B);
		
		assertTrue(A.getNeighbours().size() == 2 && A.getNeighbours().contains(C) && A.getNeighbours().contains(D));
		assertFalse(A.getNeighbours().contains(B));
	}

	/**
	 * Test method for {@link Node#getMessage()}.
	 */
	@Test
	public final void testGetMessage() {
		A.setMessage("Hello");
		assertEquals("Hello", A.getMessage());
	}

	/**
	 * Test method for {@link Node#removeAllNeighbours()}.
	 */
	@Test
	public final void testRemoveAllNeighbours() {
		Node B = new Node('B', 1, 2);
		Node C = new Node('C', 1, 5);
		
		A.addNeighbour(B);
		A.addNeighbour(C);
		
		A.removeAllNeighbours();
		
		assertTrue(A.getNeighbours().size() == 0);
		assertFalse(A.getNeighbours().contains(B) || A.getNeighbours().contains(C) || A.getNeighbours().contains(D));
	}

	/**
	 * Test method for {@link Node#setMessage(java.lang.String)}.
	 */
	@Test
	public final void testSetMessage() {
		A.setMessage("Hello");
		assertEquals("Hello", A.getMessage());
	}

	/**
	 * Test method for {@link Node#toString()}.
	 */
	@Test
	public final void testToString() {
		assertEquals("NodeA: neighbors{D}\t\t Messages{}", A.toString());
	}

	/**
	 * Test method for {@link Node#addAttribute(Attribute)}.
	 */
	@Test
	public final void testAddAttribute() {
		Attribute attribute = new Attribute("Hello", A, D, 2);
		A.addAttribute(attribute);
		
		assertTrue(A.getAttributes().size() == 1 && A.getAttributes().contains(attribute));
	}

	/**
	 * Test method for {@link Node#removeAttribute(Attribute)}.
	 */
	@Test
	public final void testRemoveAttribute() {
		Attribute attribute = new Attribute("Hello", A, D, 2);
		A.addAttribute(attribute);
		A.removeAttribute(attribute);
		
		assertTrue(A.getAttributes().size() == 0);
		assertFalse(A.getAttributes().contains(attribute));
	}

	/**
	 * Test method for {@link Node#getAttributes()}.
	 */
	@Test
	public final void testGetAttributes() {
		Attribute attribute = new Attribute("Hello", A, D, 2);
		A.addAttribute(attribute);
		
		assertTrue(A.getAttributes().size() == 1 && A.getAttributes().contains(attribute));
	}

	/**
	 * Test method for {@link Node#step()}.
	 */
	@Test
	public final void testStep() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link Node#gety_Loc()}.
	 */
	@Test
	public final void testGety_Loc() {
		assertEquals(4, A.gety_Loc());
	}

	/**
	 * Test method for {@link Node#getx_Loc()}.
	 */
	@Test
	public final void testGetx_Loc() {
		assertEquals(2, A.getx_Loc());
	}

}
