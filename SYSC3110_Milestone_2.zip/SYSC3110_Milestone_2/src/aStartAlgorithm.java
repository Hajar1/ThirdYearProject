/**
 * Team Choice Routing Algorithm.
 */
import java.lang.Math;

public class aStartAlgorithm extends Strategy {
	
	  public aStartAlgorithm(Attribute attribute){
		  
		  this.attribute = attribute;
		  
	  }
	  
	  
	  //remember to re-factor this and add it the the strategy class or make an interface for it
	  public void attributeLocationChanger(Node newCurrentnode){
		  	attribute.setOldNode(attribute.getCurrentNode());
			attribute.setCurrentNode(newCurrentnode);
			attribute.incrementHops();
			attribute.incrementPackets();
		  
	  }
	  
	  /**
	   * Team choice routing algorithm. 
	   *
	   *
	   *This algorithm is taking in consideration that the expense of traveling from node N to node M is = 1 
	   *hence based the A*start equation: F= g+h ; g-> 1 & h-> Distance equation;
	   *
	   */
	  public Attribute algorithmInterface(){
		  double bestDistance=999999.99;
		  double temp;
		  Node bestNode=null;
		  if(attribute.getCurrentNode() == attribute.getDestinationNode()){
			  System.out.println("My start and end are the same");
			  //attributeLocationChanger(bestNode);
			  return attribute;
		  }
		  for(Node n:attribute.getCurrentNode().getNeighbours()){
			  if(n == attribute.getDestinationNode()){
				  System.out.println("It seems that my Dest in my neighbour");	
				  bestNode = n;
				  attributeLocationChanger(bestNode);
				  return attribute;  
			  }
			  
			  
			  temp = Math.sqrt(Math.pow(n.getx_Loc() - attribute.getDestinationNode().getx_Loc(),2) -  (Math.pow(n.gety_Loc() - attribute.getDestinationNode().gety_Loc(),2)));
			  System.out.println("Distance value:"+ temp);
			  if(temp <= 0.0000002){
				  bestNode = n;
				  attributeLocationChanger(bestNode);
				  return attribute;
			  }
			  else if(temp < bestDistance){
				 bestDistance = temp;  
				 bestNode = n;
			  }
		  }
		  attributeLocationChanger(bestNode);
		return attribute;}
}
