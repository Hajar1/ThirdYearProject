import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.HashMap;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import com.mxgraph.swing.mxGraphComponent;
import com.mxgraph.view.mxGraph;

public class GraphGUI extends JFrame implements ActionListener {
	protected static mxGraph graph = new mxGraph();
	protected static HashMap m = new HashMap();
	private mxGraphComponent graphComponent;
	private JTextField nodeNameField;
	private JButton addNodeButton;
	private JButton deleteElementButton;
	private JButton connectNodesButton;
	private Object graphElement;

	public static HashMap getM() {
		return m;
	}

	/*
	 * public static mxGraph graph { return graph; }
	 */

	public GraphGUI() {
		super("JGraph Demo");
		initGUI();
	}

	private void initGUI() {
		setSize(700, 500);
		setLocationRelativeTo(null);

		graphComponent = new mxGraphComponent(graph);
		graphComponent.setPreferredSize(new Dimension(670, 380));
		getContentPane().add(graphComponent);

		nodeNameField = new JTextField();
		getContentPane().add(nodeNameField);
		nodeNameField.setPreferredSize(new Dimension(420, 21));
		setLayout(new FlowLayout(FlowLayout.LEFT));

		addNodeButton = new JButton("Add");
		getContentPane().add(addNodeButton);
		addNodeButton.addActionListener(this);

		deleteElementButton = new JButton("Delete");
		getContentPane().add(deleteElementButton);
		deleteElementButton.addActionListener(this);

		connectNodesButton = new JButton("Connect");
		getContentPane().add(connectNodesButton);
		connectNodesButton.addActionListener(this);

		graphComponent.getGraphControl().addMouseListener(new MouseAdapter() {
			public void mouseReleased(MouseEvent e) {
				graphElement = graphComponent.getCellAt(e.getX(), e.getY());
			}
		});
	}

	public void actionPerformed(ActionEvent event) {
		if (event.getSource() == addNodeButton) {
			String name = nodeNameField.getText();
			graph.getModel().beginUpdate();
			Object parent = graph.getDefaultParent();
			Object v1 = graph.insertVertex(parent, null, name, 330, 30, 100, 50);
			getM().put(name, v1);
			graph.getModel().endUpdate();
			nodeNameField.setText("");
		}

		else if (event.getSource() == deleteElementButton) {
			graph.getModel().remove(graphElement);
		}

		else if (event.getSource() == connectNodesButton) {
			Object parent = graph.getDefaultParent();
			Object v1 = getM().get(JOptionPane.showInputDialog("Enter first Node:"));
			Object v2 = getM().get(JOptionPane.showInputDialog("Enter second Node:"));
			String nome = JOptionPane.showInputDialog("Add Message to Arrow");
			graph.insertEdge(parent, null, nome, v1, v2);
		}

	}

	public static void main(String args[]) {
		GraphGUI a = new GraphGUI();
		a.setVisible(true);
	}

}