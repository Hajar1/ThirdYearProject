import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

/**
 * 
 */

public class ModelTest {

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * Test method for {@link Model#Model()}.
	 */
	@Test
	public final void testModel() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link Model#Model(java.util.ArrayList)}.
	 */
	@Test
	public final void testModelArrayListOfNode() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link Model#Model(java.util.ArrayList, java.util.ArrayList)}.
	 */
	@Test
	public final void testModelArrayListOfNodeArrayListOfAttribute() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link Model#Model(java.util.ArrayList, java.util.ArrayList, Strategy)}.
	 */
	@Test
	public final void testModelArrayListOfNodeArrayListOfAttributeStrategy() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link Model#getHopsAverage()}.
	 */
	@Test
	public final void testGetHopsAverage() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link Model#findNode(char)}.
	 */
	@Test
	public final void testFindNode() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link Model#createAttribute(java.lang.String, char, char)}.
	 */
	@Test
	public final void testCreateAttribute() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link Model#incrementNBofattributes()}.
	 */
	@Test
	public final void testIncrementNBofattributes() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link Model#att_complete()}.
	 */
	@Test
	public final void testAtt_complete() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link Model#getAttributes()}.
	 */
	@Test
	public final void testGetAttributes() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link Model#setAttributes(java.util.ArrayList)}.
	 */
	@Test
	public final void testSetAttributes() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link Model#fixNodeAttributes()}.
	 */
	@Test
	public final void testFixNodeAttributes() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link Model#stepSimulate()}.
	 */
	@Test
	public final void testStepSimulate() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link Model#getNumofattributes()}.
	 */
	@Test
	public final void testGetNumofattributes() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link Model#getNumOfPackets()}.
	 */
	@Test
	public final void testGetNumOfPackets() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link Model#connect(char, char)}.
	 */
	@Test
	public final void testConnect() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link Model#disconnect(char, char)}.
	 */
	@Test
	public final void testDisconnect() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link Model#setRate(int)}.
	 */
	@Test
	public final void testSetRate() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link Model#toString()}.
	 */
	@Test
	public final void testToString() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link Model#getListOfNodes()}.
	 */
	@Test
	public final void testGetListOfNodes() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link Model#insertNode(char, int, int)}.
	 */
	@Test
	public final void testInsertNode() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link Model#findLoc(int, int)}.
	 */
	@Test
	public final void testFindLoc() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link Model#deleteNode(char)}.
	 */
	@Test
	public final void testDeleteNode() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link Model#testPopulate()}.
	 */
	@Test
	public final void testTestPopulate() {
		fail("Not yet implemented"); // TODO
	}

}
