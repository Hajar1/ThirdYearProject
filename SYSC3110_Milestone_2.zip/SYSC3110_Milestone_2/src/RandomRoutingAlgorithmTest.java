import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

/**
 * 
 */

/**
 * @author omaribrahim
 *
 */
public class RandomRoutingAlgorithmTest {

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * Test method for {@link RandomRoutingAlgorithm#algorithmInterface()}.
	 */
	@Test
	public final void testAlgorithmInterface() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link RandomRoutingAlgorithm#RandomRoutingAlgorithm(Attribute)}.
	 */
	@Test
	public final void testRandomRoutingAlgorithm() {
		fail("Not yet implemented"); // TODO
	}

}
