import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class AttributeTest {

	private Attribute attribute = null; 
	private Node nodeA = null;
	private Node nodeB = null;
	
	@Before
	public void setUp() throws Exception {
		nodeA = new Node('A', 10, 10);
		nodeB = new Node('B', 20, 20);
		attribute = new Attribute("Hi", nodeA, nodeB, 2);
	}

	@Test
	public final void testAttribute() {
		// Expected, actual
		assertEquals("Hi",attribute.getMessage());
		assertEquals(nodeA,attribute.getCurrentNode());
		assertEquals(nodeB,attribute.getDestinationNode());
		assertEquals(2,attribute.getnum());
		assertEquals(0,attribute.getNumOfHops());
		assertEquals(0,attribute.getNumOfPackets());
		assertEquals(null, attribute.getOldNode());
	}

	@Test
	public final void testIncrementHops() {
		attribute.incrementHops();
		assertEquals(1, attribute.getNumOfHops());
	}

	@Test
	public final void testIncrementPackets() {
		attribute.incrementPackets();
		assertEquals(1, attribute.getNumOfPackets());
	}

	@Test
	public final void testGetMessage() {
		assertEquals("Hi",attribute.getMessage());
	}

	@Test
	public final void testGetCurrentNode() {
		assertEquals(nodeA,attribute.getCurrentNode());
	}

	@Test
	public final void testSetCurrentNode() {
		attribute.setCurrentNode(nodeB);
		assertEquals(nodeB,attribute.getCurrentNode());
	}

	@Test
	public final void testGetOldNode() {
		assertEquals(null, attribute.getOldNode());
	}

	@Test
	public final void testSetOldNode() {
		attribute.setOldNode(nodeA);
		assertEquals(nodeA,attribute.getOldNode());
	}

	@Test
	public final void testGetDestinationNode() {
		assertEquals(nodeB,attribute.getDestinationNode());
	}

	@Test
	public final void testSetDestination() {
		attribute.setDestination(nodeA);
		assertEquals(nodeA,attribute.getDestinationNode());
	}

	@Test
	public final void testGetNumOfHops() {
		assertEquals(0,attribute.getNumOfHops());
	}

	@Test
	public final void testGetnum() {
		assertEquals(2,attribute.getnum());
	}

	@Test
	public final void testGetNumOfPackets() {
		assertEquals(0,attribute.getNumOfPackets());
	}

	@Test
	public final void testToString() {
		assertEquals("Message 2: message is at Node A now",attribute.toString());
	}

	@Test
	public final void testSetStrategy() {
		attribute.setStrategy();
		Strategy strategy = new aStartAlgorithm(attribute);
		assertTrue(attribute.getStrategy().getClass().equals(strategy.getClass()));
	}

	@Test
	public final void testgetStrategy(){
		assertTrue(attribute.getStrategy().getClass().equals((new aStartAlgorithm(attribute)).getClass()));
	}
	
	@Test
	public final void testStep() {
		fail("Not Yet Implemented.");
	}

}
