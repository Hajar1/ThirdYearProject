/**
 * Class for breadth first search.   
 */
public class FloodingRoutingAlgorithm extends Strategy {
	
	/**
	 * Constructor for Flooding Routing Algorithm. 
	 * Not Yet Implemented. 
	 */
      public FloodingRoutingAlgorithm(){}
	
	/**
	 * Algorithm for Flooding Routing Algorithm. 
	 * Not Yet Implemented. 
	 */
	  public Attribute algorithmInterface(){
		return attribute;}
}
